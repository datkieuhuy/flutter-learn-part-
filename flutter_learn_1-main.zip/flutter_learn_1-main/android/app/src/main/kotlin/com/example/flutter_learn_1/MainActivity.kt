package com.example.flutter_learn_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
